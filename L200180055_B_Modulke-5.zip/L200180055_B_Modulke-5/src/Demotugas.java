/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WIN 8.1
 */
public class Demotugas {
    public static void main(String[] args){
        Tugas tg = new Tugas("M.Hanan Hafidh Arindra","L200180055",2018);
    }
}
