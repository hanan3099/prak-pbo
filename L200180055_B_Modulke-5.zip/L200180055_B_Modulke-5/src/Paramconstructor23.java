/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WIN 8.1
 */
public class Paramconstructor23 {
    String nama,nim;
    int semester;
public Paramconstructor23 (String nama,int semester,String nim){
    this.nama = nama;
    this.nim = nim;
    this.semester = semester;
}
public void info(){
    System.out.println("Nama: " + nama +"\n" + "Nim: " + nim +"\n" + "Semester: " + semester +"\n");
}
}
