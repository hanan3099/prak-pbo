/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WIN 8.1
 */
public class latihan1acces {
    public static void main(String[] args){
        latihan1 lt1 = new latihan1();
    }
}
