/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WIN 8.1
 */
public class Tugas {
    public Tugas(){
        System.out.println("Selamat datang di kelas B Mata Kuliah OOP");
    }
    public Tugas(String nama,String nim,int angkatan){
        this();
        System.out.println("Selamat Bergabung" + "\n"+"Nama :"+nama +"\n" + "NIM:"+nim+"\n" +"Angkatan: "+angkatan+"\n");
    }
    
}
