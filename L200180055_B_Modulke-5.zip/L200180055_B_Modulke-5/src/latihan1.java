/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WIN 8.1
 */
public class latihan1 {
    String nama = "M.Hanan Hafidh Arindra";
    String nim = "L200180055";
    String alamat = "KRA";
    
    latihan1(){
        System.out.println("Nama:" +nama+"\n" +"Nim:"+nim+"\n"+"Alamat: " + alamat+"\n");
}
}
