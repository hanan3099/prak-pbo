/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WIN 8.1
 */
public class Smartphone {
    String merek;
    String warna;
    String type;
    double harga;
        
    void berimerek (String merekSmartphone) {
    merek = merekSmartphone;
    }

    void beriwarna(String warnaSmartphone) {
        warna = warnaSmartphone;
        }
    
    void beritype (String typeSmartphone) {
            type = typeSmartphone;
    }

    void hargaJual (double hargaSmartphone) {
            harga  = hargaSmartphone;
    }
    
    void infoSmartphone(){
        System.out.println(
            "Merek Smartphone : " + merek + "\n" +
            "Warna Smartphone : "+ warna +"\n"+
            "Type Smartphone  : " + type + "\n" + "Harga Smartphone : Rp." + harga);                           
    }               
   
}
