/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author WIN 8.1
 */
public class RotiDemo {
    public static void main (String[] args) {
       Roti roti = new Roti ();
       roti.beriWarna("Merah");
       roti.berirasa("Strawberry");
       roti.timbangBerat(250);
       roti.hargaJual(7500);
       roti.infoRoti();
       
   }
}
